import * as wasm from "./meticulous_web.js";
import init from "./meticulous_web.js";

init();

